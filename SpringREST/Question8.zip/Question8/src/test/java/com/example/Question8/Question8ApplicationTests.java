package com.example.Question8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Question8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
