package com.example.Question6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Question6Application {

	public static void main(String[] args) {
		SpringApplication.run(Question6Application.class, args);
	}

}
