package com.example.Question2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Question2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
